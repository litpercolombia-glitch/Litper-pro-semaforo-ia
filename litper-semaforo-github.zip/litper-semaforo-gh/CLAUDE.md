# LitperPro Semaforo — Guia para Claude Code

## Que es esto
Dashboard logistico COD de Litper Group LLC (Duitama, Colombia).
El archivo principal es `public/index.html` — contiene toda la logica en un solo HTML de 292KB.

## Lo que tienes que hacer

### Prioridad 1: Conectar Supabase Auth
Agregar login con email/password y Google OAuth.
Supabase ya esta listo: https://gtsivwbnhcawvmsfujby.supabase.co
Las 7 tablas ya estan creadas con RLS.

### Prioridad 2: Guardar datos en Supabase
Cuando el usuario sube un Excel, en vez de guardar en localStorage,
guardar en las tablas: uploads, city_stats, carrier_stats.

### Prioridad 3: API backend para Gemini
Crear /api/ai.js (Vercel Edge Function) que reciba el prompt
y llame a Gemini con la key en variable de entorno del servidor.
Actualmente la key esta en el frontend (inseguro).

## Supabase
- URL: https://gtsivwbnhcawvmsfujby.supabase.co
- Anon key: ver .env.example
- Tablas: organizations, profiles, uploads, city_stats, carrier_stats, ai_analyses, chat_sessions
- Schema completo en: supabase/migrations/001_schema.sql

## Vercel
- Team: team_NatP2ZfiRnuEUHoydeDtHX5C
- Proyecto actual: asda3eeee (prj_kI6O555rFBGuNl9mlVR5EqB6tvs1)

## Como correr localmente
```bash
npx serve public -p 3000
# Abrir http://localhost:3000
```

## Reglas
- El semaforo usa verde >= 80.5%, amarillo >= 70%, rojo < 70%
- CPA logistico = $15.000 COP / tasa_entrega
- Meta tasa entrega: 85% (actual ~80.5%)
- Carriers principales: Coordinadora, Interrapidisimo, TCC, Envia
